﻿using FantasyMvvm;

using $safeprojectname$.Views;

namespace $safeprojectname$
{
    public partial class App : FantasyBootStarter
    {
        public App()
        {
            InitializeComponent();

        }

        protected override string CreateShell()
        {
            return nameof(LoginView);
        }
    }
}
