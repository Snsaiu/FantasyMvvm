﻿using CommunityToolkit.Mvvm.Input;

using FantasyMvvm;
using FantasyMvvm.FantasyNavigation;

using $safeprojectname$.Views;

namespace $safeprojectname$.ViewModels;

public partial class LoginViewModel : FantasyPageModelBase
{
    private readonly INavigationService _navigationService;

    public LoginViewModel(INavigationService navigationService)
    {
        _navigationService = navigationService;
    }
    [RelayCommand]
    private Task GoHome()
    {
        return Task.FromResult(_navigationService.NavigationToAsync(nameof(HomePage), null));
    }
}