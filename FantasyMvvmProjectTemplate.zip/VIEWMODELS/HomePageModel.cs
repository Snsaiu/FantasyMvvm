﻿using FantasyMvvm;

namespace $safeprojectname$.ViewModels
{
    internal class HomePageModel : FantasyPageModelBase
    {

    }
}
