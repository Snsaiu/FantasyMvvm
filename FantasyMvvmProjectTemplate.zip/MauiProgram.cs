﻿using CommunityToolkit.Maui;

using FantasyMvvm;

using $safeprojectname$.ViewModels;
using $safeprojectname$.Views;

using Microsoft.Extensions.Logging;

namespace $safeprojectname$
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            MauiAppBuilder builder = MauiApp.CreateBuilder();
            builder.UseMauiApp<App>().ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            }).UseFantasyApplication().UseGetProvider().UseMauiCommunityToolkit();
#if DEBUG
            builder.Logging.AddDebug();
#endif
            builder.UseRegisterPage<LoginView, LoginViewModel>();
            builder.UseRegisterPage<HomePage, HomePageModel>();
            return builder.Build();
        }
    }
}